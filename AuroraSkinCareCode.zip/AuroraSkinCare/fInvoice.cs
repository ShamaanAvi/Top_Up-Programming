﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AuroraSkinCare
{
    public partial class fInvoice : Form
    {
        public fInvoice()
        {
            InitializeComponent();
        }

        private void fInvoice_Load(object sender, EventArgs e)
        {

        }

        public void SetInvoiceData(string patientName, string doctorName, string treatmentName,
                           DateTime appointmentDate, TimeSpan appointmentTime,
                           decimal amount, decimal tax, decimal totalAmount, DateTime paymentDate)
        {
            lblPatientName.Text = $"Patient: {patientName}";
            lblDoctorName.Text = $"Doctor: {doctorName}";
            lblTreatmentName.Text = $"Treatment: {treatmentName}";
            lblAppointmentDate.Text = $"Date: {appointmentDate.ToShortDateString()}";
            lblAppointmentTime.Text = $"Time: {appointmentTime}";
            lblAmount.Text = $"Amount: {amount:C}";
            lblTax.Text = $"Tax: {tax:C}";
            lblTotalAmount.Text = $"Total: {totalAmount:C}";
            lblPaymentDate.Text = $"Payment Date: {paymentDate.ToShortDateString()}";
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();
        }

        private void btnAv_Click(object sender, EventArgs e)
        {

        }

        private void btnApp_Click(object sender, EventArgs e)
        {

        }
    }
}

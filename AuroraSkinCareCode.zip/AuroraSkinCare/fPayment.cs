﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AuroraSkinCare
{
    public partial class fPayment : Form
    {
        string connectionString = @"Data Source=DESKTOP-DAME84Q\SQLEXPRESS;Initial Catalog=AuroraSkinCareDB;User ID=sa;Password=Shaamil123;";
        public fPayment()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnChk_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // SQL query to find appointments without corresponding payments
                    string query = @"
                SELECT A.AppointmentID, P.Name AS PatientName, D.Name AS DoctorName, A.AppointmentDate, A.AppointmentTime, T.TreatmentName
                FROM Appointment A
                JOIN Patient P ON A.PatientID = P.PatientID
                JOIN Doctor D ON A.DoctorID = D.DoctorID
                JOIN Treatment T ON A.TreatmentID = T.TreatmentID
                LEFT JOIN Payment Pay ON A.AppointmentID = Pay.AppointmentID
                WHERE Pay.AppointmentID IS NULL;";

                    SqlCommand cmd = new SqlCommand(query, con);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Bind the result to the DataGridView
                    dgPay.DataSource = dt;

                    // Optional: Adjust column headers for better readability
                    dgPay.Columns["AppointmentID"].HeaderText = "Appointment ID";
                    dgPay.Columns["PatientName"].HeaderText = "Patient Name";
                    dgPay.Columns["DoctorName"].HeaderText = "Doctor";
                    dgPay.Columns["AppointmentDate"].HeaderText = "Date";
                    dgPay.Columns["AppointmentTime"].HeaderText = "Time";
                    dgPay.Columns["TreatmentName"].HeaderText = "Treatment";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void fPayment_Load(object sender, EventArgs e)
        {

        }

        private void btnPro_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Get the AppointmentID from the text box
                    if (!int.TryParse(txtApp.Text.Trim(), out int appointmentID))
                    {
                        MessageBox.Show("Please enter a valid Appointment ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    // Query to get the price of the treatment for the specified AppointmentID
                    string query = @"
                SELECT T.Price
                FROM Appointment A
                JOIN Treatment T ON A.TreatmentID = T.TreatmentID
                WHERE A.AppointmentID = @AppointmentID";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentID);

                    // Execute the query and retrieve the price
                    var priceResult = cmd.ExecuteScalar();
                    if (priceResult == null)
                    {
                        MessageBox.Show("No appointment found with the given ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Calculate Amount, Tax, and TotalAmount
                    decimal amount = Convert.ToDecimal(priceResult);
                    decimal tax = amount * 0.025m;  // 2.5% tax
                    decimal totalAmount = amount + tax;

                    // Insert the payment into the Payment table
                    string insertPaymentQuery = @"
                INSERT INTO Payment (AppointmentID, Amount, Tax, TotalAmount)
                VALUES (@AppointmentID, @Amount, @Tax, @TotalAmount)";

                    SqlCommand insertCmd = new SqlCommand(insertPaymentQuery, con);
                    insertCmd.Parameters.AddWithValue("@AppointmentID", appointmentID);
                    insertCmd.Parameters.AddWithValue("@Amount", amount);
                    insertCmd.Parameters.AddWithValue("@Tax", tax);
                    insertCmd.Parameters.AddWithValue("@TotalAmount", totalAmount);

                    int rowsAffected = insertCmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Payment processed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to process the payment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnInv_Click(object sender, EventArgs e)
        {
            string appointmentID = txtApp.Text.Trim();

            // Check if AppointmentID is provided
            if (string.IsNullOrEmpty(appointmentID))
            {
                // Show a dialog box asking if the user wants to proceed
                DialogResult result = MessageBox.Show("Appointment ID isn't added. Would you still like to go to the Invoices Menu?",
                                                      "Invoice Menu", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    // Open fInvoice form without appointment-specific data
                    fInvoice invoiceForm = new fInvoice();
                    invoiceForm.Show();
                }
                // No action is taken if "No" is selected, user stays on the form
            }
            else
            {
                // Proceed with retrieving data for the specified AppointmentID
                int appID;
                if (int.TryParse(appointmentID, out appID))
                {
                    // Fetch data from the database
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();

                        // SQL query to fetch relevant appointment, payment, and patient details
                        string query = @"SELECT 
                                    P.Name AS PatientName,
                                    D.Name AS DoctorName,
                                    T.TreatmentName,
                                    A.AppointmentDate,
                                    A.AppointmentTime,
                                    Pay.Amount,
                                    Pay.Tax,
                                    Pay.TotalAmount,
                                    Pay.PaymentDate
                                 FROM Payment Pay
                                 INNER JOIN Appointment A ON Pay.AppointmentID = A.AppointmentID
                                 INNER JOIN Patient P ON A.PatientID = P.PatientID
                                 INNER JOIN Doctor D ON A.DoctorID = D.DoctorID
                                 INNER JOIN Treatment T ON A.TreatmentID = T.TreatmentID
                                 WHERE A.AppointmentID = @AppointmentID";

                        using (SqlCommand cmd = new SqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@AppointmentID", appID);
                            SqlDataReader reader = cmd.ExecuteReader();

                            if (reader.Read())
                            {
                                // Extract the required data
                                string patientName = reader["PatientName"].ToString();
                                string doctorName = reader["DoctorName"].ToString();
                                string treatmentName = reader["TreatmentName"].ToString();
                                DateTime appointmentDate = Convert.ToDateTime(reader["AppointmentDate"]);
                                TimeSpan appointmentTime = (TimeSpan)reader["AppointmentTime"];
                                decimal amount = (decimal)reader["Amount"];
                                decimal tax = (decimal)reader["Tax"];
                                decimal totalAmount = (decimal)reader["TotalAmount"];
                                DateTime paymentDate = (DateTime)reader["PaymentDate"];

                                // Open fInvoice form and pass the data
                                fInvoice invoiceForm = new fInvoice();
                                invoiceForm.SetInvoiceData(patientName, doctorName, treatmentName, appointmentDate, appointmentTime, amount, tax, totalAmount, paymentDate);
                                invoiceForm.Show();
                            }
                            else
                            {
                                MessageBox.Show("No payment found for the given Appointment ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please enter a valid Appointment ID.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();
        }
    }
}

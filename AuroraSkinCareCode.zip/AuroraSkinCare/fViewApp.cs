﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AuroraSkinCare
{
    public partial class fViewApp : Form
    {
        // Connection string
        string connectionString = @"Data Source=DESKTOP-DAME84Q\SQLEXPRESS;Initial Catalog=AuroraSkinCareDB;User ID=sa;Password=Shaamil123;";
        public fViewApp()
        {
            InitializeComponent();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private DataTable GetAvailableTimeSlots(TimeSpan consultationStart, TimeSpan consultationEnd, DataTable bookedAppointments)
        {
            DataTable availableSlots = new DataTable();
            availableSlots.Columns.Add("AvailableSlot", typeof(string)); // Adjust the column as per your requirement

            // Create a list of booked times to easily check against
            List<TimeSpan> bookedTimes = new List<TimeSpan>();
            foreach (DataRow row in bookedAppointments.Rows)
            {
                bookedTimes.Add((TimeSpan)row["AppointmentTime"]);
            }

            // Loop through consultation hours, checking each slot for availability
            TimeSpan slotDuration = TimeSpan.FromMinutes(15); // Slot duration
            for (TimeSpan currentSlot = consultationStart; currentSlot < consultationEnd; currentSlot += slotDuration)
            {
                TimeSpan slotEnd = currentSlot + slotDuration;
                bool isAvailable = true;

                // Check if the slot clashes with any existing booked appointment
                foreach (var bookedTime in bookedTimes)
                {
                    // Ensure that the slot does not overlap with a booked appointment
                    if ((currentSlot < bookedTime + slotDuration) && (slotEnd > bookedTime))
                    {
                        // There's an overlap if the current slot starts before the end of a booked appointment 
                        // and ends after the start of the booked appointment
                        isAvailable = false;
                        break;
                    }
                }

                // Add the time slot to available slots if it's not overlapping
                if (isAvailable)
                {
                    DataRow row = availableSlots.NewRow();
                    row["AvailableSlot"] = currentSlot.ToString(@"hh\:mm") + " - " + slotEnd.ToString(@"hh\:mm");
                    availableSlots.Rows.Add(row);
                }


            }

            return availableSlots;
        }

        // Show Booked Appointments for the Selected Date
        private void btnApp_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dtApp.Value.Date;

            // Clear and refresh the DataGridView before loading new data
            dgApp.DataSource = null;
            dgApp.Refresh();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                string query = @"
            SELECT 
                p.Name AS PatientName, 
                a.AppointmentTime, 
                d.Name AS DoctorName, 
                t.TreatmentName
            FROM Appointment a
            JOIN Patient p ON a.PatientID = p.PatientID
            JOIN Doctor d ON a.DoctorID = d.DoctorID
            JOIN Treatment t ON a.TreatmentID = t.TreatmentID
            WHERE a.AppointmentDate = @AppointmentDate";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AppointmentDate", selectedDate);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);

                    // Set the DataGridView DataSource to display booked appointments
                    dgApp.DataSource = dt;
                }
            }
        }

        private void btnAv_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dtApp.Value.Date;
            string selectedDay = selectedDate.DayOfWeek.ToString(); // Get the name of the day (e.g., "Monday")

            // Clear and refresh the DataGridView before loading new data
            dgApp.DataSource = null;
            dgApp.Refresh();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Query to get doctor's available consultation time for the selected day
                string scheduleQuery = @"
            SELECT ds.ConsultationStart, ds.ConsultationEnd 
            FROM DoctorSchedule ds
            WHERE ds.ConsultationDay = @ConsultationDay";

                using (SqlCommand cmdSchedule = new SqlCommand(scheduleQuery, con))
                {
                    cmdSchedule.Parameters.AddWithValue("@ConsultationDay", selectedDay);

                    con.Open();
                    SqlDataReader reader = cmdSchedule.ExecuteReader();

                    if (reader.Read())
                    {
                        TimeSpan consultationStart = (TimeSpan)reader["ConsultationStart"];
                        TimeSpan consultationEnd = (TimeSpan)reader["ConsultationEnd"];
                        reader.Close();

                        // Now get all booked appointments for this doctor on the selected date
                        string bookedQuery = @"
                    SELECT a.AppointmentTime 
                    FROM Appointment a
                    WHERE a.AppointmentDate = @AppointmentDate";

                        using (SqlCommand cmdBooked = new SqlCommand(bookedQuery, con))
                        {
                            cmdBooked.Parameters.AddWithValue("@AppointmentDate", selectedDate);

                            SqlDataAdapter da = new SqlDataAdapter(cmdBooked);
                            DataTable bookedAppointments = new DataTable();
                            da.Fill(bookedAppointments);

                            // Calculate available time slots with at least 15 minutes apart
                            DataTable availableSlots = GetAvailableTimeSlots(consultationStart, consultationEnd, bookedAppointments);

                            // Display available slots in dgApp
                            dgApp.DataSource = availableSlots;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No consultation schedule found for the selected day.");
                    }
                }
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AuroraSkinCare
{
    public partial class fMain : Form
    {
        public fMain()
        {
            InitializeComponent();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        // Click event for 'Make Appointment' button
        private void btnMake_Click(object sender, EventArgs e)
        {
            // Open fMakeApp form
            fMakeApp makeAppForm = new fMakeApp();
            makeAppForm.Show();
        }

        // Click event for 'View Appointments' button
        private void btnView_Click(object sender, EventArgs e)
        {
            // Open fViewApp form
            fViewApp viewAppForm = new fViewApp();
            viewAppForm.Show();
        }

        // Click event for 'Update Appointment' button
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            // Open fUpdateApp form
            fUpdateApp updateAppForm = new fUpdateApp();
            updateAppForm.Show();
        }

        // Click event for 'Process Payment' button
        private void btnPay_Click(object sender, EventArgs e)
        {
            // Open fPayment form
            fPayment paymentForm = new fPayment();
            paymentForm.Show();
        }

        // Click event for 'Generate Invoice' button
        private void btnInv_Click(object sender, EventArgs e)
        {
            // Open fInvoice form
            fInvoice invoiceForm = new fInvoice();
            invoiceForm.Show();
        }

        private void fMain_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Create an instance of the fMain form
            fLogin LoginForm = new fLogin();

            // Show the fMain form
            LoginForm.Show();
        }
    }
}

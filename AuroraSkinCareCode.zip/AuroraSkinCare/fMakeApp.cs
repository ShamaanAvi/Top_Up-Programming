﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Globalization;

namespace AuroraSkinCare
{
    public partial class fMakeApp : Form
    {
        // Connection string
        string connectionString = @"Data Source=DESKTOP-DAME84Q\SQLEXPRESS;Initial Catalog=AuroraSkinCareDB;User ID=sa;Password=Shaamil123;";
        public fMakeApp()
        {
            InitializeComponent();
        }

        private void fMakeApp_Load(object sender, EventArgs e)
        {
            LoadDoctorNames();      // Method when the form loads to populate the ComboBox for Doctor's name
            LoadTreatmentNames();   // Method when the form loads to populate the ComboBox for treatment's name
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        // Click event for 'Book Appointment' button
        private void btnBook_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtNIC.Text) || string.IsNullOrEmpty(txtName.Text) ||
        string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPhone.Text) ||
        cbDerm.SelectedItem == null || cbTreat.SelectedItem == null)
            {
                MessageBox.Show("Please complete all fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string nic = txtNIC.Text;
            string name = txtName.Text;
            string email = txtEmail.Text;
            string phone = txtPhone.Text;
            string selectedDermatologist = cbDerm.SelectedItem.ToString();
            string selectedTreatment = cbTreat.SelectedItem.ToString();
            DateTime selectedDate = dtAppDate.Value.Date;
            TimeSpan selectedTime = dtAppTime.Value.TimeOfDay;

            // Validate if the selected dermatologist is available on the chosen date and time
            if (!IsDermatologistAvailable(selectedDermatologist, selectedDate, selectedTime))
            {
                MessageBox.Show("The selected dermatologist is not available on the chosen date and time. Please choose a different time.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check for overlapping appointments
            if (!IsAppointmentAvailable(selectedDermatologist, selectedDate, selectedTime))
            {
                MessageBox.Show("The selected appointment time is not available. Please choose a different time.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    int patientID = GetPatientID(nic, conn);
                    if (patientID == 0)
                    {
                        patientID = InsertPatient(nic, name, email, phone, conn);
                    }

                    int doctorID = GetDoctorID(selectedDermatologist, conn);
                    int treatmentID = GetTreatmentID(selectedTreatment, conn);
                    InsertAppointment(patientID, doctorID, treatmentID, selectedDate, selectedTime, conn);

                    MessageBox.Show("Appointment successfully booked!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while booking the appointment: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // Method to check if the dermatologist is available on the chosen date and time
        private bool IsDermatologistAvailable(string doctorName, DateTime date, TimeSpan time)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
            SELECT DS.ConsultationDay, DS.ConsultationStart, DS.ConsultationEnd 
            FROM DoctorSchedule DS
            INNER JOIN Doctor D ON DS.DoctorID = D.DoctorID
            WHERE D.Name = @DoctorName
            AND DS.ConsultationDay = @ConsultationDay";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DoctorName", doctorName);
                    cmd.Parameters.AddWithValue("@ConsultationDay", date.DayOfWeek.ToString()); // Get the day of the week as a string (e.g., "Monday")

                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            TimeSpan consultationStart = (TimeSpan)reader["ConsultationStart"];
                            TimeSpan consultationEnd = (TimeSpan)reader["ConsultationEnd"];

                            // Check if the selected time falls within the consultation time range
                            if (time >= consultationStart && time < consultationEnd)
                            {
                                return true; // Dermatologist is available
                            }
                        }
                    }
                }
            }
            return false; // Dermatologist is not available
        }


        // Check if there is an overlapping appointment
        private bool IsAppointmentAvailable(string doctorName, DateTime date, TimeSpan time)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = @"
            SELECT COUNT(*) 
            FROM Appointment A
            INNER JOIN Doctor D ON A.DoctorID = D.DoctorID
            WHERE D.Name = @DoctorName
            AND A.AppointmentDate = @AppointmentDate
            AND ABS(DATEDIFF(minute, A.AppointmentTime, @AppointmentTime)) < 15";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@DoctorName", doctorName);
                    cmd.Parameters.AddWithValue("@AppointmentDate", date);
                    cmd.Parameters.AddWithValue("@AppointmentTime", time);

                    int count = (int)cmd.ExecuteScalar();
                    return count == 0; // If count is 0, the slot is available
                }
            }
        }

        // Method to get existing patient ID by NIC
        private int GetPatientID(string nic, SqlConnection conn)
        {
            string query = "SELECT PatientID FROM Patient WHERE NIC = @NIC";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@NIC", nic);
                object result = cmd.ExecuteScalar();
                return result != null ? Convert.ToInt32(result) : 0;
            }
        }

        // Method to insert a new patient and return PatientID
        private int InsertPatient(string nic, string name, string email, string phone, SqlConnection conn)
        {
            string query = @"
                INSERT INTO Patient (NIC, Name, Email, Phone) 
                OUTPUT INSERTED.PatientID 
                VALUES (@NIC, @Name, @Email, @Phone)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@NIC", nic);
                cmd.Parameters.AddWithValue("@Name", name);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@Phone", phone);

                return (int)cmd.ExecuteScalar();
            }
        }

        // Method to get DoctorID by doctor name
        private int GetDoctorID(string doctorName, SqlConnection conn)
        {
            string query = "SELECT DoctorID FROM Doctor WHERE Name = @DoctorName";
            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@DoctorName", doctorName);
                return (int)cmd.ExecuteScalar();
            }
        }

        // Method to insert a new appointment
        private void InsertAppointment(int patientID, int doctorID, int treatmentID, DateTime date, TimeSpan time, SqlConnection conn)
        {
            string query = @"
        INSERT INTO Appointment (PatientID, DoctorID, AppointmentDate, AppointmentTime, TreatmentID) 
        VALUES (@PatientID, @DoctorID, @AppointmentDate, @AppointmentTime, @TreatmentID)";

            using (SqlCommand cmd = new SqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@PatientID", patientID);
                cmd.Parameters.AddWithValue("@DoctorID", doctorID);
                cmd.Parameters.AddWithValue("@AppointmentDate", date);
                cmd.Parameters.AddWithValue("@AppointmentTime", time);
                cmd.Parameters.AddWithValue("@TreatmentID", treatmentID);

                cmd.ExecuteNonQuery();
            }
        }

        // Method to populate the ComboBox with doctor names from the database
        private void LoadDoctorNames()
        {
            // SQL query to retrieve doctor names from the Doctor table
            string query = "SELECT Name FROM Doctor";

            // Open a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Create the SQL command
                    SqlCommand command = new SqlCommand(query, connection);

                    // Open the connection
                    connection.Open();

                    // Execute the query and read the data
                    SqlDataReader reader = command.ExecuteReader();

                    // Clear any existing items in the ComboBox
                    cbDerm.Items.Clear();

                    // Loop through the results and add each doctor name to the ComboBox
                    while (reader.Read())
                    {
                        // Add doctor name to the ComboBox
                        cbDerm.Items.Add(reader["Name"].ToString());
                    }

                    // Close the reader
                    reader.Close();
                }
                catch (Exception ex)
                {
                    // Display any errors that occur during the database connection or query execution
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void dtApp_ValueChanged(object sender, EventArgs e)
        {

        }

        // Method to populate the ComboBox with treatment names from the database
        private void LoadTreatmentNames()
        {
            // SQL query to retrieve treatment names from the Treatment table
            string query = "SELECT TreatmentName FROM Treatment";

            // Open a connection to the database
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Create the SQL command
                    SqlCommand command = new SqlCommand(query, connection);

                    // Open the connection
                    connection.Open();

                    // Execute the query and read the data
                    SqlDataReader reader = command.ExecuteReader();

                    // Clear any existing items in the ComboBox
                    cbTreat.Items.Clear();

                    // Loop through the results and add each treatment name to the ComboBox
                    while (reader.Read())
                    {
                        // Add treatment name to the ComboBox
                        cbTreat.Items.Add(reader["TreatmentName"].ToString());
                    }

                    // Close the reader
                    reader.Close();
                }
                catch (Exception ex)
                {
                    // Display any errors that occur during the database connection or query execution
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // Method to get TreatmentID by treatment name
        private int GetTreatmentID(string treatmentName, SqlConnection conn)
        {
        string query = "SELECT TreatmentID FROM Treatment WHERE TreatmentName = @TreatmentName";
        using (SqlCommand cmd = new SqlCommand(query, conn))
            {
            cmd.Parameters.AddWithValue("@TreatmentName", treatmentName);
            return (int)cmd.ExecuteScalar();
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();

        }
    }
}

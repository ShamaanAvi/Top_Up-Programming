﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AuroraSkinCare
{
    public partial class fLogin : Form
    {
        // Connection string
        readonly string connectionString = @"Data Source=DESKTOP-DAME84Q\SQLEXPRESS;Initial Catalog=AuroraSkinCareDB;User ID=sa;Password=Shaamil123;";
        public fLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUser.Text.Trim();
            string password
     = txtPass.Text;

            if (ValidateCredentials(username, password))
            {
                // Open the main form if login is successful
                fMain mainForm = new fMain();
                mainForm.Show();
                this.Hide(); // Optionally hide the login form
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }

        private bool ValidateCredentials(string username, string password)

        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM [User] WHERE Username = @Username AND Password = @Password";
    
            using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Username", username);
                    cmd.Parameters.AddWithValue("@Password", password);


                    int result = (int)cmd.ExecuteScalar();
                    return result> 0;
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

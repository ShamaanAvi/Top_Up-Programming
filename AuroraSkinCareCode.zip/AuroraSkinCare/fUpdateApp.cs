﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AuroraSkinCare
{
    public partial class fUpdateApp : Form
    {
        // Connection string
        string connectionString = @"Data Source=DESKTOP-DAME84Q\SQLEXPRESS;Initial Catalog=AuroraSkinCareDB;User ID=sa;Password=Shaamil123;";
        public fUpdateApp()
        {
            InitializeComponent();

            // Wire up the event handlers
            dtAppDate.ValueChanged += dtAppDate_ValueChanged_1;
        }

        private void btnSrch_Click(object sender, EventArgs e)
        {
            string searchInput = txtName.Text.Trim();
            if (string.IsNullOrWhiteSpace(searchInput))
            {
                MessageBox.Show("Please enter a valid name or appointment ID.");
                return;
            }

            DataTable appointments = SearchAppointments(searchInput);
            if (appointments.Rows.Count > 0)
            {
                dgApp.DataSource = appointments;
            }
            else
            {
                MessageBox.Show("No appointments found.");
            }
        }

        private DataTable SearchAppointments(string searchInput)
        {
            DataTable dtAppointments = new DataTable();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query;

                // Check if the input is a number (likely AppointmentID)
                if (int.TryParse(searchInput, out int appointmentId))
                {
                    query = @"
                SELECT A.AppointmentID, P.Name, A.AppointmentDate, A.AppointmentTime, D.Name AS DoctorName, T.TreatmentName
                FROM Appointment A
                JOIN Patient P ON A.PatientID = P.PatientID
                JOIN Doctor D ON A.DoctorID = D.DoctorID
                JOIN Treatment T ON A.TreatmentID = T.TreatmentID
                WHERE A.AppointmentID = @AppointmentID
                ORDER BY A.AppointmentDate DESC, A.AppointmentTime DESC";
                }
                else
                {
                    query = @"
                SELECT A.AppointmentID, P.Name, A.AppointmentDate, A.AppointmentTime, D.Name AS DoctorName, T.TreatmentName
                FROM Appointment A
                JOIN Patient P ON A.PatientID = P.PatientID
                JOIN Doctor D ON A.DoctorID = D.DoctorID
                JOIN Treatment T ON A.TreatmentID = T.TreatmentID
                WHERE P.Name LIKE '%' + @Name + '%'
                ORDER BY A.AppointmentDate DESC, A.AppointmentTime DESC";
                }

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    if (int.TryParse(searchInput, out appointmentId))
                        cmd.Parameters.AddWithValue("@AppointmentID", appointmentId);
                    else
                        cmd.Parameters.AddWithValue("@Name", searchInput);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(dtAppointments);
                }
            }
            return dtAppointments;
        }

        private void btnUp_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();

                    // Fetch the input values
                    string patientName = txtName.Text.Trim();
                    int selectedDoctorID = (int)cbDerm.SelectedValue; // Gets the selected dermatologist
                    DateTime selectedDate = dtAppDate.Value.Date; // Get the selected date
                    TimeSpan selectedTime = dtTime.Value.TimeOfDay; // Get the selected time
                    string selectedDay = selectedDate.DayOfWeek.ToString(); // Get the day of the week (e.g., Monday)

                    // Check if the user entered a valid patient name or appointment ID
                    if (string.IsNullOrEmpty(patientName))
                    {
                        MessageBox.Show("Please enter a valid Patient Name or Appointment ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Step 1: Check the dermatologist's availability for the selected date and time
                    string scheduleQuery = @"
                SELECT ConsultationStart, ConsultationEnd 
                FROM DoctorSchedule 
                WHERE DoctorID = @DoctorID AND ConsultationDay = @ConsultationDay";

                    SqlCommand scheduleCmd = new SqlCommand(scheduleQuery, con);
                    scheduleCmd.Parameters.AddWithValue("@DoctorID", selectedDoctorID);
                    scheduleCmd.Parameters.AddWithValue("@ConsultationDay", selectedDay);

                    SqlDataReader scheduleReader = scheduleCmd.ExecuteReader();

                    if (scheduleReader.Read())
                    {
                        TimeSpan consultationStart = (TimeSpan)scheduleReader["ConsultationStart"];
                        TimeSpan consultationEnd = (TimeSpan)scheduleReader["ConsultationEnd"];
                        scheduleReader.Close();

                        // Step 2: Validate if the selected time falls within the consultation hours
                        if (selectedTime < consultationStart || selectedTime >= consultationEnd)
                        {
                            MessageBox.Show($"The selected time is outside the dermatologist's consultation hours: {consultationStart:hh\\:mm} - {consultationEnd:hh\\:mm}.", "Invalid Time", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No consultation schedule found for the selected day.", "Schedule Not Found", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        scheduleReader.Close();
                        return;
                    }

                    // Step 3: Check if there's a payment for the appointment
                    int retrievedAppointmentID = 0;
                    string getAppointmentIDQuery;

                    // If a patient name is entered, find the latest appointment for that patient
                    if (int.TryParse(patientName, out int appointmentID)) // If user entered an Appointment ID
                    {
                        getAppointmentIDQuery = "SELECT TOP 1 AppointmentID FROM Appointment WHERE AppointmentID = @AppointmentID ORDER BY AppointmentDate DESC, AppointmentTime DESC";
                    }
                    else // If the user entered a Patient Name
                    {
                        getAppointmentIDQuery = "SELECT TOP 1 A.AppointmentID FROM Appointment A " +
                                                "JOIN Patient P ON A.PatientID = P.PatientID " +
                                                "WHERE P.Name LIKE @PatientName " +
                                                "ORDER BY A.AppointmentDate DESC, A.AppointmentTime DESC";
                    }

                    SqlCommand getAppointmentIDCmd = new SqlCommand(getAppointmentIDQuery, con);
                    if (int.TryParse(patientName, out int id))
                    {
                        getAppointmentIDCmd.Parameters.AddWithValue("@AppointmentID", id);
                    }
                    else
                    {
                        getAppointmentIDCmd.Parameters.AddWithValue("@PatientName", $"%{patientName}%");
                    }

                    var appointmentIDResult = getAppointmentIDCmd.ExecuteScalar();
                    if (appointmentIDResult == null)
                    {
                        MessageBox.Show("No appointment found for the given patient or appointment ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    retrievedAppointmentID = Convert.ToInt32(appointmentIDResult);

                    // Step 4: Use the IsAppointmentPaid method to check if payment has been made
                    if (IsAppointmentPaid(retrievedAppointmentID))
                    {
                        MessageBox.Show("This appointment cannot be updated as a payment has already been processed.", "Payment Processed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }

                    // Step 5: Perform the update if no payment has been made and the time is valid
                    string updateQuery = "UPDATE Appointment SET DoctorID = @DoctorID, AppointmentDate = @AppointmentDate, AppointmentTime = @AppointmentTime WHERE AppointmentID = @AppointmentID";
                    SqlCommand updateCmd = new SqlCommand(updateQuery, con);
                    updateCmd.Parameters.AddWithValue("@DoctorID", selectedDoctorID);
                    updateCmd.Parameters.AddWithValue("@AppointmentDate", selectedDate);
                    updateCmd.Parameters.AddWithValue("@AppointmentTime", selectedTime);
                    updateCmd.Parameters.AddWithValue("@AppointmentID", retrievedAppointmentID);

                    int rowsAffected = updateCmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Appointment updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Failed to update the appointment.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDel_Click(object sender, EventArgs e)
        {
            if (dgApp.CurrentRow != null)
            {
                int appointmentId = Convert.ToInt32(dgApp.CurrentRow.Cells["AppointmentID"].Value);
                DeleteAppointment(appointmentId);
            }
            else
            {
                MessageBox.Show("Please select an appointment to delete.");
            }
        }

        private void DeleteAppointment(int appointmentId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                // First, check if the appointment is paid for
                if (IsAppointmentPaid(appointmentId))
                {
                    MessageBox.Show("This appointment cannot be deleted because the payment has already been processed.");
                    return;
                }

                // Delete the appointment
                string query = "DELETE FROM Appointment WHERE AppointmentID = @AppointmentID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentId);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show("Appointment deleted successfully.");
            }
        }

        private bool IsAppointmentPaid(int appointmentId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT COUNT(*) FROM Payment WHERE AppointmentID = @AppointmentID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@AppointmentID", appointmentId);
                    int count = (int)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }

        



  
        private void fUpdateApp_Load(object sender, EventArgs e)
        {
            LoadDermatologists();
        }

        private void LoadDermatologists()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                string query = "SELECT DoctorID, Name FROM Doctor";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dtDerm = new DataTable();
                    da.Fill(dtDerm);
                    cbDerm.DataSource = dtDerm;
                    cbDerm.DisplayMember = "Name";
                    cbDerm.ValueMember = "DoctorID";
                }
            }
        }

        

        private void dtAppDate_ValueChanged_1(object sender, EventArgs e)
        {
            
        }

        public class Doctor
        {
            public int DoctorID { get; set; }
            public string Name { get; set; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime selectedDate = dtAppDate.Value.Date;
            string selectedDay = selectedDate.DayOfWeek.ToString(); // Get the name of the day (e.g., "Monday")

            // Clear and refresh the DataGridView before loading new data
            dgApp.DataSource = null;
            dgApp.Refresh();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Query to get doctor's available consultation time for the selected day
                string scheduleQuery = @"
            SELECT ds.ConsultationStart, ds.ConsultationEnd 
            FROM DoctorSchedule ds
            WHERE ds.ConsultationDay = @ConsultationDay";

                using (SqlCommand cmdSchedule = new SqlCommand(scheduleQuery, con))
                {
                    cmdSchedule.Parameters.AddWithValue("@ConsultationDay", selectedDay);

                    con.Open();
                    SqlDataReader reader = cmdSchedule.ExecuteReader();

                    if (reader.Read())
                    {
                        TimeSpan consultationStart = (TimeSpan)reader["ConsultationStart"];
                        TimeSpan consultationEnd = (TimeSpan)reader["ConsultationEnd"];
                        reader.Close();

                        // Now get all booked appointments for this doctor on the selected date
                        string bookedQuery = @"
                    SELECT a.AppointmentTime 
                    FROM Appointment a
                    WHERE a.AppointmentDate = @AppointmentDate";

                        using (SqlCommand cmdBooked = new SqlCommand(bookedQuery, con))
                        {
                            cmdBooked.Parameters.AddWithValue("@AppointmentDate", selectedDate);

                            SqlDataAdapter da = new SqlDataAdapter(cmdBooked);
                            DataTable bookedAppointments = new DataTable();
                            da.Fill(bookedAppointments);

                            // Calculate available time slots with at least 15 minutes apart
                            DataTable availableSlots = GetAvailableTimeSlots(consultationStart, consultationEnd, bookedAppointments);

                            // Display available slots in dgApp
                            dgApp.DataSource = availableSlots;
                        }
                    }
                    else
                    {
                        MessageBox.Show("No consultation schedule found for the selected day.");
                    }
                }
            }
        }

        private DataTable GetAvailableTimeSlots(TimeSpan consultationStart, TimeSpan consultationEnd, DataTable bookedAppointments)
        {
            DataTable availableSlots = new DataTable();
            availableSlots.Columns.Add("AvailableSlot", typeof(string)); // Adjust the column as per your requirement

            // Create a list of booked times to easily check against
            List<TimeSpan> bookedTimes = new List<TimeSpan>();
            foreach (DataRow row in bookedAppointments.Rows)
            {
                bookedTimes.Add((TimeSpan)row["AppointmentTime"]);
            }

            // Loop through consultation hours, checking each slot for availability
            TimeSpan slotDuration = TimeSpan.FromMinutes(15); // Slot duration
            for (TimeSpan currentSlot = consultationStart; currentSlot < consultationEnd; currentSlot += slotDuration)
            {
                TimeSpan slotEnd = currentSlot + slotDuration;
                bool isAvailable = true;

                // Check if the slot clashes with any existing booked appointment
                foreach (var bookedTime in bookedTimes)
                {
                    // Ensure that the slot does not overlap with a booked appointment
                    if ((currentSlot < bookedTime + slotDuration) && (slotEnd > bookedTime))
                    {
                        // There's an overlap if the current slot starts before the end of a booked appointment 
                        // and ends after the start of the booked appointment
                        isAvailable = false;
                        break;
                    }
                }

                // Add the time slot to available slots if it's not overlapping
                if (isAvailable)
                {
                    DataRow row = availableSlots.NewRow();
                    row["AvailableSlot"] = currentSlot.ToString(@"hh\:mm") + " - " + slotEnd.ToString(@"hh\:mm");
                    availableSlots.Rows.Add(row);
                }
            }

            return availableSlots;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            // Close the current form
            this.Close();
        }
    }
            
}
USE [master];
GO

-- Create Database
CREATE DATABASE [AuroraSkinCareDB]
ON PRIMARY 
( NAME = N'AuroraSkinCareDB', 
  FILENAME = N'D:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\AuroraSkinCareDB.mdf', 
  SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB ) 
LOG ON 
( NAME = N'AuroraSkinCareDB_log', 
  FILENAME = N'D:\Program Files\Microsoft SQL Server\MSSQL15.SQLEXPRESS\MSSQL\DATA\AuroraSkinCareDB_log.ldf', 
  SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB );
GO

USE [AuroraSkinCareDB];
GO

-- Table: Doctor
CREATE TABLE [dbo].[Doctor] (
    [DoctorID] INT IDENTITY(1,1) PRIMARY KEY,
    [Name] NVARCHAR(100) NOT NULL
);
GO

-- Table: DoctorSchedule
CREATE TABLE [dbo].[DoctorSchedule] (
    [ScheduleID] INT IDENTITY(1,1) PRIMARY KEY,
    [DoctorID] INT NOT NULL,
    [ConsultationDay] NVARCHAR(20) NOT NULL,
    [ConsultationStart] TIME NOT NULL,
    [ConsultationEnd] TIME NOT NULL,
    FOREIGN KEY ([DoctorID]) REFERENCES [dbo].[Doctor] ([DoctorID]) ON DELETE CASCADE
);
GO

-- Table: Patient
CREATE TABLE [dbo].[Patient] (
    [PatientID] INT IDENTITY(1,1) PRIMARY KEY,
    [NIC] NVARCHAR(12) UNIQUE NOT NULL,
    [Name] NVARCHAR(100) NOT NULL,
    [Email] NVARCHAR(100) UNIQUE NOT NULL,
    [Phone] NVARCHAR(15) NOT NULL
);
GO

-- Table: Treatment
CREATE TABLE [dbo].[Treatment] (
    [TreatmentID] INT IDENTITY(1,1) PRIMARY KEY,
    [TreatmentName] NVARCHAR(50) NOT NULL,
    [Price] DECIMAL(10, 2) NOT NULL
);
GO

-- Table: Appointment
CREATE TABLE [dbo].[Appointment] (
    [AppointmentID] INT IDENTITY(1,1) PRIMARY KEY,
    [PatientID] INT NOT NULL,
    [DoctorID] INT NULL,
    [AppointmentDate] DATE NOT NULL,
    [AppointmentTime] TIME NOT NULL,
    [TreatmentID] INT NULL,
    CONSTRAINT [UK_Appointment] UNIQUE ([PatientID], [DoctorID], [AppointmentDate], [AppointmentTime]),
    FOREIGN KEY ([DoctorID]) REFERENCES [dbo].[Doctor] ([DoctorID]) ON DELETE SET NULL,
    FOREIGN KEY ([PatientID]) REFERENCES [dbo].[Patient] ([PatientID]) ON DELETE CASCADE,
    FOREIGN KEY ([TreatmentID]) REFERENCES [dbo].[Treatment] ([TreatmentID])
);
GO

-- Table: Payment
CREATE TABLE [dbo].[Payment] (
    [PaymentID] INT IDENTITY(1,1) PRIMARY KEY,
    [AppointmentID] INT UNIQUE NOT NULL,
    [Amount] DECIMAL(12, 2) NOT NULL,
    [Tax] DECIMAL(12, 2) NOT NULL,
    [TotalAmount] DECIMAL(12, 2) NOT NULL,
    [PaymentDate] DATETIME DEFAULT GETDATE(),
    FOREIGN KEY ([AppointmentID]) REFERENCES [dbo].[Appointment] ([AppointmentID]) ON DELETE CASCADE
);
GO

-- Table: User
CREATE TABLE [dbo].[User] (
    [UserID] INT IDENTITY(1,1) PRIMARY KEY,
    [Username] NVARCHAR(50) UNIQUE NOT NULL,
    [Password] NVARCHAR(255) NOT NULL
);
GO
